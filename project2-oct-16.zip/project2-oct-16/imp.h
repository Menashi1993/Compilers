#include <iostream>
#include <stdlib.h>
#include <string>
#include <map>
#include <vector>
#include <list>
#include <algorithm>
#include <iostream>
#include <fstream>
#include <sstream>

using namespace std;

class exp_node {
public:

	// print function for pretty printing an expression
	virtual void print() = 0;

	// evaluation function for a leaf, replaced for interior nodes
	virtual float evaluate() = 0;
};

class str_node {
public:

	// print function for pretty printing an expression
	virtual void print() = 0;

	// evaluation function for a leaf, replaced for interior nodes
	virtual string evaluate() = 0;
};

class binaryOp_node : public exp_node {
public:
	exp_node *left;
	exp_node *right;

	// the constructor for node links the node to its children,
	// and stores the character representation of the operator.
	binaryOp_node(exp_node *L, exp_node *R);
};

class boolOp_node : public exp_node {
public:
	exp_node *left;
	exp_node *right;

	// the constructor for node links the node to its children,
	// and stores the character representation of the operator.
	boolOp_node(exp_node *L, exp_node *R);
};

class number_node : public exp_node {
private:
	float num;

public:
	number_node(float value);
	void print();
	float evaluate();
};

class boolean_type : public exp_node {
private:
	bool value;
public:
	boolean_type(bool value);
	void print();
	float evaluate();
};

class string_node : public str_node {
private:
	string id;
public:
	string_node(string value);
	void print();
	string evaluate();
};

class neg_node : public exp_node {
protected:
	exp_node *exp;
public:
	neg_node(exp_node *exp);
	void print();
	float evaluate();
};

class variable_node : public exp_node {
protected:
	string id;

public:
	variable_node(string value);
	void print();
	float evaluate();
};


class str_var_node : public str_node {
protected:
	string id;

public:
	str_var_node(string value);
	void print();
	string evaluate();
};

// equal_node inherits the characteristics of node and adds its own evaluate function
class equal_node : public boolOp_node {
public:
	// equal_node's constructor just uses node's constructor
	equal_node(exp_node *L, exp_node *R);
	void print();
	float evaluate();
};

// noteq_node inherits the characteristics of node and adds its own evaluate function
class noteq_node : public boolOp_node {
public:

	// noteq_node's constructor just uses node's constructor
	noteq_node(exp_node *L, exp_node *R);
	void print();
	float evaluate();
};

// less_node inherits the characteristics of node and adds its own evaluate function
class less_node : public boolOp_node {
public:

	// less_node's constructor just uses node's constructor
	less_node(exp_node *L, exp_node *R);
	void print();
	float evaluate();
};

class less_eq_node : public boolOp_node {
public:

	// less_eq_node's constructor just uses node's constructor
	less_eq_node(exp_node *L, exp_node *R);
	void print();
	float evaluate();
};

class greater_node : public boolOp_node {
public:

	// greater_node's constructor just uses node's constructor
	greater_node(exp_node *L, exp_node *R);
	void print();
	float evaluate();
};

class greater_eq_node : public boolOp_node {
public:

	// greater_eq_node's constructor just uses node's constructor
	greater_eq_node(exp_node *L, exp_node *R);
	void print();
	float evaluate();
};

// add_node inherits the characteristics of node and adds its own evaluate function
class add_node : public binaryOp_node {
public:

	// add_node's constructor just uses node's constructor
	add_node(exp_node *L, exp_node *R);
	void print();
	float evaluate();
};


class string_concat : public str_node {
protected:
	str_node *left;
	str_node *right;
public:
	string_concat(str_node *L, str_node *R);
	void print();
	string evaluate();
};

// subtract_node inherits the characteristics of node and adds its own evaluate function
class subtract_node : public binaryOp_node {
public:
	subtract_node(exp_node *L, exp_node *R);
	void print();
	float evaluate();
};


// multiply_node inherits the characteristics of node and adds its own evaluate function
class multiply_node : public binaryOp_node {
public:
	multiply_node(exp_node *L, exp_node *R);
	void print();
	float evaluate();
};


// divide_node inherits the characteristics of node and adds its own evaluate function
class divide_node : public binaryOp_node {
public:
	divide_node(exp_node *L, exp_node *R);
	void print();
	float evaluate();
};

// modulo_node inherits the characteristics of node and adds its own evaluate function
class modulo_node : public binaryOp_node {
public:
	modulo_node(exp_node *L, exp_node *R);
	void print();
	float evaluate();
};

class stmt_node {
public:
	virtual void print() {}
	virtual void evaluate() = 0;
};

class assign_node : public stmt_node {
protected:
	string id;
	exp_node *exp;
public:
	assign_node(string name, exp_node *expression);
	void print();
	void evaluate();
};


class assign_node_str : public stmt_node {
protected:
	string id;
	str_node *str;
public:
	assign_node_str(string name, str_node *str);
	void print();
	void evaluate();
};

class print_node: public stmt_node {
protected:
	exp_node *exp;
public:
	print_node(exp_node *myexp);
	void print();
	void evaluate();
};

class print_string_node: public stmt_node {
protected:
	str_node *str;
public:
	print_string_node(str_node *str);
	void print();
	void evaluate();
};

class skip_node: public stmt_node {
public:
	skip_node();
	void print();
	void evaluate();
};


class sequence_node: public stmt_node {
protected:
	stmt_node *stmt1, *stmt2;
public:
	sequence_node(stmt_node *mystmt1, stmt_node *mystmt2);
	void print();
	void evaluate();
};



class conjunction_node : public boolOp_node {
public:
	conjunction_node(exp_node *L, exp_node *R);
	void print();
	float evaluate();
};

class disjunction_node : public boolOp_node {
public:
	disjunction_node(exp_node *L, exp_node *R);
	void print();
	float evaluate();
};

class negation_node : public exp_node {
protected:
	exp_node *exp;
public:
	negation_node(exp_node *exp);
	void print();
	float evaluate();
};

class if_stmt : public stmt_node {
protected: 
	stmt_node *left;
	exp_node *right;	
public:
	if_stmt(stmt_node *L, exp_node *R);
	void print();
	void evaluate();
};

class if_else_statement: public stmt_node {
protected:
	stmt_node* if_statement;
	stmt_node* else_statement;
	exp_node* bool_exp;
public:
	if_else_statement(stmt_node* if_stm, stmt_node* else_stm,exp_node* boolean_exp);
	void print();
	void evaluate();
};

class while_stmt : public stmt_node {
protected:
	stmt_node* statements;
	exp_node* bool_exp;

public:
	while_stmt(stmt_node* statements, exp_node* bool_exp);
	void print();
	void evaluate();
};


class break_node: public stmt_node {
public:
	break_node();
	void print();
	void evaluate();
};



class assign_node_type : public stmt_node {
protected:
	string id;
	exp_node *exp;
	string datatype;
public:
	assign_node_type(string name, exp_node *expression,string datatype);
	void print();
	void evaluate();
};

class assign_string : public stmt_node {
protected:
	string id;
	str_node *str;
public:
	assign_string(string name, str_node *str);
	void print();
	void evaluate();
};

class pluseqassign_stmt: public assign_node {
public:
	pluseqassign_stmt(string name, exp_node *expression);
	void print();
	void evaluate();
};

class minuseqassignStmt: public assign_node {
public:
	minuseqassignStmt(string name, exp_node *expression);
	void print();
	void evaluate();
};

class multiply_eq_assgin_stmt: public assign_node {
public:
	multiply_eq_assgin_stmt(string name, exp_node *expression);
	void print();
	void evaluate();
};

class division_eq_assign_stmt: public assign_node {
public:
	division_eq_assign_stmt(string name, exp_node *expression);
	void print();
	void evaluate();
};

class modulus_eq_assign_stmt: public assign_node {
public:
	modulus_eq_assign_stmt(string name, exp_node *expression);
	void print();
	void evaluate();
};


class de_seq : public stmt_node {
protected:
	stmt_node* stmt1;
	stmt_node* stmt2;
public:
	de_seq(stmt_node* stmt1, stmt_node* stmt2);
	void print();
	void evaluate();
};

class assignType : public stmt_node {
protected:
	string id;
	string datatype;
public:
	assignType(string name,string datatype);
	void print();
	void evaluate();
};

class array1D_node : public stmt_node{
protected:  
	string variableName;
	int arraySize;
	exp_node *arrInitList;
	string dataType;

public:
	array1D_node(string varName, int arraySize, exp_node *arrInitList, string dataType);
	void print();
	void evaluate();
};

class change_arr_val : public stmt_node{
protected:
	string arrName;
	exp_node *arrIndex;
	exp_node *assignVal;
public: 
	change_arr_val(string arrName, exp_node *arrIndex, exp_node *assignVal);
	void print();
	void evaluate();   
};

class get_arr_element : public exp_node{
protected:
	string arrName;
	exp_node *exp;

public:
	get_arr_element(string value, exp_node *exp);
	void print();
	float evaluate();
};

class get_array_size : public exp_node{
protected:
	string arrName;

public:
	get_array_size(string value);
	void print();
	float evaluate();
};

class assign_arr_val : public stmt_node {
protected:
	string varName;
	exp_node *exp;
public:
	assign_arr_val(string varName, exp_node *expression);
	void print();
	void evaluate();
};

class function_declaration: public stmt_node {
protected:
	string funcReturnType;
	string funcName;
	stmt_node* funcParams;
	stmt_node* funcBody;

public:
	function_declaration(string returnType, string name, stmt_node* formalArgs, stmt_node* bodyStmt);
	void print();
	void evaluate();
};

class function_arg_list: public exp_node {
protected:
	exp_node* exp1;
	exp_node* exp2;

public:
	function_arg_list(exp_node* exp1, exp_node* exp2);
	function_arg_list(exp_node* exp1);
	void print();
	float evaluate();
};


class function_call: public stmt_node {
protected:
	string funcName;
	exp_node* funcArgsList;

public:
	function_call(string name, exp_node* dec_seq);
	void print();
	void evaluate();
};


// the object at the base of our tree
extern map<string, string> string_map;
extern map<string, float> state;
extern map<string, string> data_type_check;
extern vector<float> vectorInts;
extern map<string, vector<float> > array1D;