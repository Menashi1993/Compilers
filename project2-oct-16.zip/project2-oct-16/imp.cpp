#include <iostream>
#include <stdlib.h>
#include <string>
#include <map>
#include <list>
#include <vector>
#include "imp.h"
#include <algorithm>
#include <iostream>
#include <fstream>
#include <sstream>
#include <typeinfo>
#include <cstdlib> //to convert string to int

using namespace std;

// the constructor for node links the node to its children,
// and stores the character representation of the operator.
binaryOp_node::binaryOp_node(exp_node *L, exp_node *R) {
	left    = L;
	right   = R;
}

boolOp_node::boolOp_node(exp_node *L, exp_node *R) {
	left    = L;
	right   = R;
}

number_node::number_node(float value) {
	num = value;
}

void number_node:: print() {
	cout << num;
}

float number_node::evaluate() { 
	return num; 
}

boolean_type::boolean_type(bool value) : value(value) {}
void boolean_type:: print() {
	cout << value;
}

float boolean_type::evaluate() { 
	return value; 
}


string_node::string_node(string value) : id(value) {}

void string_node:: print() {
	cout << id;
}

string string_node::evaluate() { 
	return id;
}


variable_node::variable_node(string value) : id(value) {}
void variable_node:: print() {
	cout << id;
}

float variable_node::evaluate() {  

	return state[id]; 
}

str_var_node::str_var_node(string value) : id(value) {}
void str_var_node:: print() {
	cout << id;
}

string str_var_node::evaluate() {  
	return string_map[id]; 
}


equal_node::equal_node(exp_node *L, exp_node *R) : boolOp_node(L,R) { }
void equal_node:: print() {
	cout << "(";
	left->print();
	cout << " == ";
	right->print();
	cout << ")";
}

float equal_node::evaluate() {
	float left_num, right_num;

	left_num  = left->evaluate();
	right_num = right->evaluate();

	return  left_num == right_num;

}


noteq_node::noteq_node(exp_node *L, exp_node *R) : boolOp_node(L,R) { }
void noteq_node:: print() {
	cout << "(";
	left->print();
	cout << " != ";
	right->print();
	cout << ")";
}

float noteq_node::evaluate() {
	float left_num, right_num;

	left_num  = left->evaluate();
	right_num = right->evaluate();

	return  left_num != right_num;
}


less_node::less_node(exp_node *L, exp_node *R) : boolOp_node(L,R) { }
void less_node:: print() {
	cout << "(";
	left->print();
	cout << " < ";
	right->print();
	cout << ")";
}

float less_node::evaluate() {
	float left_num, right_num;

	left_num  = left->evaluate();
	right_num = right->evaluate();

	return  (left_num < right_num);
}

less_eq_node::less_eq_node(exp_node *L, exp_node *R) : boolOp_node(L,R) { }
void less_eq_node:: print() {
	cout << "(";
	left->print();
	cout << " <= ";
	right->print();
	cout << ")";
}

float less_eq_node::evaluate() {
	float left_num, right_num;

	left_num  = left->evaluate();
	right_num = right->evaluate();

	return  (left_num <= right_num);
}

greater_node::greater_node(exp_node *L, exp_node *R) : boolOp_node(L,R) { }
void greater_node:: print() {
	cout << "(";
	left->print();
	cout << " > ";
	right->print();
	cout << ")";
}

float greater_node::evaluate() {
	float left_num, right_num;

	left_num  = left->evaluate();
	right_num = right->evaluate();

	return  (left_num > right_num);
}

greater_eq_node::greater_eq_node(exp_node *L, exp_node *R) : boolOp_node(L,R) { }
void greater_eq_node:: print() {
	cout << "(";
	left->print();
	cout << " >= ";
	right->print();
	cout << ")";
}

float greater_eq_node::evaluate() {
	float left_num, right_num;

	left_num  = left->evaluate();
	right_num = right->evaluate();

	return  (left_num >= right_num);
}

add_node::add_node(exp_node *L, exp_node *R) : binaryOp_node(L,R) { }
void add_node:: print() {
	cout << "(";
	left->print();
	cout << " + ";
	right->print();
	cout << ")";
}

float add_node::evaluate() {
	float left_num, right_num;

	left_num  = left->evaluate();
	right_num = right->evaluate();

	return (left_num + right_num);
}

string_concat::string_concat(str_node *L, str_node *R) {
	this->left = L;
	this->right = R;
}

void string_concat:: print() {
	left->print();
	cout << " + ";
	right->print();
}

string string_concat::evaluate() {
	string left_num, right_num; 
	
	right_num = right->evaluate(); 
	right_num.erase(
	std::remove(right_num.begin(), right_num.end(), '\"'), 
	right_num.end());
	
	left_num  = left->evaluate();
	left_num.erase(
	std::remove(left_num.begin(), left_num.end(), '\"'), 
	left_num.end());
	
	return "\""+left_num + right_num+"\"";
}

// subtract_node inherits the characteristics of node and adds its own evaluate function
subtract_node::subtract_node(exp_node *L, exp_node *R) : binaryOp_node(L,R) { }
void subtract_node:: print() {
	cout << "(";
	left->print();
	cout << " - ";
	right->print();
	cout << ")";
}

float subtract_node::evaluate() {
	float left_num, right_num;

	left_num  = left->evaluate();
	right_num = right->evaluate();

	return  left_num - right_num;

}

// multiply_node inherits the characteristics of node and adds its own evaluate function
multiply_node::multiply_node(exp_node *L, exp_node *R) : binaryOp_node(L,R) { }
void multiply_node:: print() {
	cout << "(";
	left->print();
	cout << " * ";
	right->print();
	cout << ")";
}

float multiply_node::evaluate() {
	float left_num, right_num;

	left_num = left->evaluate();
	right_num = right->evaluate();

	return left_num * right_num;

}


// divide_node inherits the characteristics of node and adds its own evaluate function

divide_node::divide_node(exp_node *L, exp_node *R) : binaryOp_node(L,R) { }
void divide_node:: print() {
	cout << "(";
	left->print();
	cout << " / ";
	right->print();
	cout << ")";
}

float divide_node::evaluate() {
	float left_num, right_num;

	left_num = left->evaluate();
	right_num = right->evaluate();

	if(right_num) {
		return  left_num / right_num;
	} else {
		cout << "division by zero -> " << left_num << " / " << 0 << endl;
		//  include stdlib.h for exit
		exit(1);
	}
}

// modulo_node inherits the characteristics of binary node and adds its own evaluate function
modulo_node :: modulo_node(exp_node *L, exp_node *R) : binaryOp_node(L,R) { }
void modulo_node :: print() {
	cout << "(";
	left->print();
	cout << " % ";
	right->print();
	cout << ")";
}

float modulo_node :: evaluate() {
	float left_num, right_num;
	int test;
	left_num = left->evaluate();
	right_num = right->evaluate();

	if(right_num) {
		test = left_num / right_num;  
		return  left_num - test * right_num;
	}
	else {
		cout << "modulo by zero undefined-> " << left_num << " % " << 0 << endl;
		//  include stdlib.h for exit
		exit(1);
	}
}

neg_node::neg_node(exp_node *L) : exp(L) {}
void neg_node:: print() {
	cout << "- ( ";
	exp->print();
	cout << " )";
}

float neg_node::evaluate() {
	float expValue = exp->evaluate();
	return  -expValue;
}

assign_node::assign_node(string name, exp_node *expression) : id(name), exp(expression) {}
void assign_node::print() {
	cout << id << " = ";
	exp->print(); 
}

void assign_node::evaluate() {
	float result = exp->evaluate();
	string datatype = data_type_check[id];
	if(datatype == "$bool") {
		result = !!result;  
	} else if(datatype == "$int"){
		result = static_cast<int>(result);
	}
	state[id] = result;
}


assign_node_str::assign_node_str(string name, str_node *str) : id(name), str(str) {}
void assign_node_str::print() {
	cout << id << " = ";
	str->print();

}

void assign_node_str::evaluate() {
	string result = str->evaluate();
	string_map[id] = result;
}

print_node::print_node (exp_node *myexp) : exp(myexp) {}

void print_node::print() {
	cout <<  "print ";
	exp->print();
}


void print_node::evaluate() {
	cout << "output: " << exp->evaluate() << endl << endl;
}

print_string_node::print_string_node (str_node *str) : str(str) {}

void print_string_node::print() {
	cout <<  "prints ";
	str->print();
}

void print_string_node::evaluate() {
	cout << "output: " << str->evaluate() <<endl;
}

skip_node::skip_node ()  {}

void skip_node::evaluate() {}
void skip_node::print() {}


sequence_node::sequence_node(stmt_node* mystmt1, stmt_node* mystmt2): stmt1(mystmt1), stmt2(mystmt2) {}
void sequence_node::print() {
	stmt1->print();  cout << " ;" << endl;
	stmt2->print();
}

void sequence_node::evaluate() {
	stmt1->evaluate();
	stmt2->evaluate();
}



conjunction_node::conjunction_node(exp_node *L, exp_node *R) : boolOp_node(L,R) { }
void conjunction_node:: print() {
	cout << "(";
	left->print();
	cout << " && ";
	right->print();
	cout << ")";
}

float conjunction_node::evaluate() {
	float left_num, right_num;

	left_num  = left->evaluate();
	right_num = right->evaluate();

	return  left_num && right_num;

}

disjunction_node::disjunction_node(exp_node *L, exp_node *R) : boolOp_node(L,R) { }
void disjunction_node:: print() {
	cout << "(";
	left->print();
	cout << " || ";
	right->print();
	cout << ")";
}

float disjunction_node::evaluate() {
	float left_num, right_num;

	left_num  = left->evaluate();
	right_num = right->evaluate();

	return  left_num || right_num;

}


negation_node::negation_node(exp_node *L) : exp(L) { }
void negation_node:: print() {
	cout << "! (";
	exp ->print();
	cout << ")";
}

float negation_node:: evaluate() {
	float boolValue = exp->evaluate();
	return  !boolValue;

}


if_stmt::if_stmt(stmt_node *L,exp_node *R) {
	this->left = L;
	this->right = R; 
}

void if_stmt:: print() {
	cout << "$if ";
	right->print();
	cout << " { "<<endl;
	left->print();
	cout << " } ";
}

void if_stmt::evaluate() {
	float res = right-> evaluate();
	if(res != 0){
		left-> evaluate();
	} 
}

if_else_statement::if_else_statement(stmt_node* if_stm, stmt_node* else_stm,exp_node* boolean_exp) {
	this->bool_exp = boolean_exp;
	this->else_statement = else_stm;
	this->if_statement = if_stm;
}

void if_else_statement::print() {
	cout << "$if ";
	bool_exp->print();
	cout << " {" << endl;
	if_statement->print();
	cout << endl << "} $else { " << endl;
	else_statement->print();
	cout << endl << "}";
}

void if_else_statement::evaluate() {
	float res1 = bool_exp->evaluate();
	if(res1 >= 1){
		if_statement-> evaluate();
	}
	else {
		else_statement-> evaluate();
	}
}

while_stmt::while_stmt(stmt_node *statements, exp_node* bool_exp) {
	this->statements = statements;
	this->bool_exp = bool_exp;
}

void while_stmt::print() {
	cout << "$while";
	bool_exp->print();
	cout << "{" << endl;
	statements->print();
	cout<< "}";
}

void while_stmt::evaluate(){

	while(bool_exp->evaluate()){
		statements->evaluate();
	}
}


//break;

break_node::break_node ()  {}

void break_node::print() {
	cout<<"$break ";
}
void break_node::evaluate() {
	exit(0);
}

assign_node_type::assign_node_type(string name, exp_node *expression,string datatype) : id(name), exp(expression), datatype(datatype) {}
void assign_node_type::print() {
	cout << datatype << " " << id << " = ";
	exp->print();
}

void assign_node_type::evaluate() {
	float result = exp->evaluate();
	if(datatype == "$bool") {
		data_type_check[id] = "$bool";
		result = !!result;  
	} else if(datatype == "$int"){
		result = static_cast<int>(result);
		data_type_check[id] = "$int";
	}
	state[id] = result;
}

assign_string::assign_string(string name, str_node *str) : id(name), str(str){}
void assign_string::print() {
	cout << "String" << " " << id << " = ";
	str->print();
}

void assign_string::evaluate() {
	string result = str->evaluate();
	data_type_check[id] = "$string";
	string_map[id] = result;
}

void output_element(string symbol, string id) {
	cout << id << " " << symbol << " ";
}

pluseqassign_stmt::pluseqassign_stmt(string name,exp_node* exp) :assign_node(name, exp) {}
void pluseqassign_stmt::print() {
	output_element("+=", id);
	exp->print();
}

void pluseqassign_stmt::evaluate() {
	float result = exp->evaluate();
	float init_value = state[id];
	float final_result =  init_value + result;
	state[id] = final_result;
}

minuseqassignStmt::minuseqassignStmt(string name,exp_node* exp) :assign_node(name, exp) {}
void minuseqassignStmt::print() {
	output_element("-=", id);
	exp->print();
}

void minuseqassignStmt::evaluate() {
	float result = exp->evaluate();
	float init_value = state[id];
	float final_result =  init_value - result;
	state[id] = final_result;
}


multiply_eq_assgin_stmt::multiply_eq_assgin_stmt(string name,exp_node* exp) :assign_node(name, exp) {}
void multiply_eq_assgin_stmt::print() {
	output_element("*=", id);
	exp->print();
}

void multiply_eq_assgin_stmt::evaluate() {
	float result = exp->evaluate();
	float init_value = state[id];
	float final_result =  init_value * result;
	state[id] = final_result;
}

division_eq_assign_stmt::division_eq_assign_stmt(string name,exp_node* exp) :assign_node(name, exp) {}
void division_eq_assign_stmt::print() {
	output_element("/=", id);
	exp->print();
}

void division_eq_assign_stmt::evaluate() {
	float result = exp->evaluate();
	float init_value = state[id];
	if(result) {
		float final_result =  init_value / result;
		state[id] = final_result; 
	} else {
		cout << "modulo by zero undefined-> " << init_value << " % " << 0 << endl;
		//  include stdlib.h for exit
		exit(1);
	}
}

modulus_eq_assign_stmt::modulus_eq_assign_stmt(string name,exp_node* exp) :assign_node(name, exp) {}
void modulus_eq_assign_stmt::print() {
	output_element("%=", id);
	exp->print();
}

void modulus_eq_assign_stmt::evaluate() {
	float result = exp->evaluate();
	float init_value = state[id];
	if(result) {
		int final_result =  init_value / result;
		state[id] = init_value-final_result * result; 
	} else {	
		cout << "modulo by zero undefined-> " << init_value << " % " << 0 << endl;
		//  include stdlib.h for exit
		exit(1); 
	}
}


de_seq::de_seq(stmt_node *stmt1, stmt_node *stmt2) :stmt1(stmt1), stmt2(stmt2) {}
void de_seq::print() {
	stmt1->print();
	cout << ",";
	stmt2->print();
}

void de_seq::evaluate(){
	stmt1->evaluate(); 
	stmt2->evaluate();
}

assignType::assignType(string id,string datatype) : id(id), datatype(datatype) { }

void assignType::print() {
	cout << datatype << " ";
	cout << id;
}

void assignType::evaluate() {
	data_type_check[id] = datatype;   
	string line;
	int x = 0; 
	ifstream myfile ("funcParams.txt");
	if (myfile.is_open()) {
		while ( getline (myfile,line) ) {
			stringstream geek(line); 
			geek >> x;    
			vectorInts.push_back(x);
		}
		myfile.close();
	}        
	if (!vectorInts.empty()){
		state[id] = vectorInts.front();
		vectorInts.erase(vectorInts.begin());
	}
}

function_declaration :: function_declaration(string returnType, string name, stmt_node* formalArgs, stmt_node* bodyStmt) :
funcReturnType(returnType), funcName(name), funcParams(formalArgs), funcBody(bodyStmt) {}

void function_declaration :: print() {
	cout << funcReturnType;
	cout << " ";
	cout << funcName;
	cout << " ";
	cout << "( ";
	if (funcParams != NULL) {
		funcParams->print();
	}
	cout << " )";
	cout << " {" <<endl;
	if (funcBody != NULL) {
		funcBody->print();
	}
	cout << endl << "}";
}

void function_declaration :: evaluate(){
	funcParams->evaluate();
	funcBody->evaluate();
}

function_call::function_call(string name, exp_node* dec_seq) : funcName(name), funcArgsList(dec_seq) {}
void function_call::print() {
	cout << funcName;
	cout << "( ";
	if (funcArgsList != NULL) {
		funcArgsList->print();
	}
	cout << " )";
}
void function_call :: evaluate(){
	if(funcArgsList != NULL){
		funcArgsList->evaluate();
		ofstream myfile;
		myfile.open ("funcParams.txt");
		vector<float>::iterator it;
		for (it = vectorInts.begin(); it != vectorInts.end(); ++it){
			myfile << *it<<endl;
		}
		myfile.close();
	}
}

array1D_node::array1D_node(string varName, int arraySize, exp_node *arrInitList, string dataType){
	this->variableName = varName;
	this->arraySize = arraySize;
	this->arrInitList = arrInitList;
	this->dataType = dataType;
}
void array1D_node::print() {
	cout << dataType <<" " << variableName << "[ " << arraySize << " ]" <<" = "<<" { ";
	arrInitList->print();
	cout << " }";
}
void array1D_node :: evaluate(){
	arrInitList->evaluate();
	//check init list is same with size given
	if(arraySize == vectorInts.size()){
		vector<float> array;  
		if(dataType == "$int"){
			for (int i = 0; i < vectorInts.size(); i++) {
				array.push_back(static_cast<int>(vectorInts[i]));
			} 
		} else {
			array = vectorInts;
		}
		vectorInts.clear(); 
		array1D[variableName] = array; 
	} else {
		cout << "Array Size and Initializer list length mismatch!! " << endl;
		vectorInts.clear(); 
		exit(1);
	}
}


change_arr_val::change_arr_val(string arrName, exp_node *arrIndex, exp_node *assignVal){
	this->arrName = arrName;
	this->arrIndex = arrIndex;
	this->assignVal = assignVal;
}

void change_arr_val::print() {
	cout << arrName << "[ ";
	arrIndex->print();
	cout<< " ]" <<" = ";
	assignVal->print();
}
void change_arr_val :: evaluate(){
	int index = arrIndex->evaluate();   
	if(index < array1D[arrName].size()){
		array1D[arrName].at(index) = assignVal->evaluate();
	} else {
		cout<< "Array Index Out of bound exception" << endl;
		exit(1);
	}
}

get_arr_element::get_arr_element(string value, exp_node *exp) : arrName(value), exp(exp) {}
void get_arr_element:: print() {
	cout << arrName<< " [ ";
	exp->print();
	cout << " ] "; 
}

float get_arr_element::evaluate() { 
	int index = exp->evaluate();
	float result = 0;
	if(array1D.find( arrName ) != array1D.end()){ 
		if(index < array1D[arrName].size()){   
			result = array1D[arrName].at(index);
		} else {
			cout<< "Array Index Out of bound exception" << endl;
			exit(1);
		}
	} else {
		cout<< "Given array name is not exist in scope"<< endl;
		exit(1);
	}
	return result;
}

get_array_size::get_array_size(string value) : arrName(value){}
void get_array_size:: print() {
	cout << arrName<< "."<<"length( )"; 
}

float get_array_size::evaluate() { 
	int result;
	if(array1D.find( arrName ) != array1D.end()){ 
		result = array1D[arrName].size();
	} else {
		cout<< "Given array name is not exist in scope"<< endl;
		exit(1);
	}
	return result;
}

assign_arr_val::assign_arr_val(string varName, exp_node *expression) : varName(varName), exp(expression) {}

void assign_arr_val::print() {
	cout << varName << " = ";
	exp->print();

}

void assign_arr_val::evaluate() {
	float result = exp->evaluate();
	state[varName] = result;
}

function_arg_list::function_arg_list(exp_node* exp1,exp_node* exp2) {
	this->exp1 = exp1;
	this->exp2 = exp2;
}

function_arg_list::function_arg_list(exp_node* exp1) {
	this->exp1 = exp1;
}

void function_arg_list::print() {
	exp1->print();
	if(exp2 != NULL){
		cout << " , ";
		exp2->print();
	}
}

float function_arg_list::evaluate() {   
	float num1 = exp1->evaluate();
	float num2; 
	if(find(vectorInts.begin(), vectorInts.end(), num1) == vectorInts.end()) {
		vectorInts.push_back(num1);
	} 
	if(exp2 != NULL){
		num2 = exp2->evaluate();
		vectorInts.push_back(num2);
	}
	return num1;
}

map<string, vector<float> > array1D;
map<string, string> data_type_check;
map<string, string> string_map;
map<string, float> state; 
vector<float> vectorInts;  