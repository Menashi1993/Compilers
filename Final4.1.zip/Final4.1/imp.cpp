#include <iostream>
#include <stdlib.h>
#include <string>
#include <map>
#include <list>
#include "imp.h"
#include <vector>
#include <algorithm>

using namespace std;


map<string, float> state;

// preconditon: n>=0
void output_tabs(int n) 
{ 
	while (n>0) 
	{ cout << "\t"; 
		n--;
	}
}


or_cond_node::or_cond_node(cond_node *L, cond_node *R):
left(L), right(R)
{
}

void or_cond_node::print()
{ 
	cout << "("; 
	left->print(); cout<<") ||  ("; 
	right -> print(); cout <<")";
}

bool or_cond_node::evaluate()
{ return (left->evaluate()) || (right->evaluate()); 
} 


and_cond_node::and_cond_node(cond_node *L, cond_node *R):
left(L), right(R)
{
}

void and_cond_node::print()
{ 
	cout << "("; 
	left->print(); cout<<") &&  ("; 
	right -> print(); cout <<")";
}


bool and_cond_node::evaluate()
{ return (left->evaluate()) && (right->evaluate()); 
} 


neg_cond_node::neg_cond_node(cond_node *child)
{ this -> child = child; 
}

void neg_cond_node::print()
{ 
	cout << "! ("; 
	child->print(); 
	cout <<")";
}


bool neg_cond_node::evaluate()
{ return !(child->evaluate()); 
} 

prim_cond_node::prim_cond_node(operation op, exp_node *left, exp_node *right)
{
	this -> op = op;
	this -> left = left;
	this -> right = right;
}

void prim_cond_node::print()
{ 
	left->print();   
	switch(op)
	{ case GE: cout<< ">"; break;
	case EQ: cout << "=="; break;
	case NTEQL: cout << "!="; break;
	case GRTEQL: cout << ">="; break;
	case LE: cout<< "<" ; break;
	case LESEQL: cout<< "<="; break;
	} 
	right -> print(); 
}


bool prim_cond_node::evaluate()
{ float opdl, opdr;

	opdl = left->evaluate();
	opdr = right->evaluate(); 

	switch(op)
	{ case GE: return (opdl >opdr); break;
	case EQ: return (opdl == opdr); break;
	case NTEQL: return (opdl != opdr); break;
	case GRTEQL: return (opdl >= opdr); break;
	case LE: return (opdl < opdr); break;
	case LESEQL: return (opdl <= opdr); break;
	} 

} 


// the constructor for node links the node to its children,
// and stores the character representation of the operator.
operator_node::operator_node(exp_node *L, exp_node *R) {
	left    = L;
	right   = R;
}

string_node::string_node(string value) : id(value) {}
void string_node:: print() {
	cout << id;
}

string string_node::evaluate() { 
	return id;
}

str_var_node::str_var_node(string value) : id(value) {}
void str_var_node:: print() {
	use_vars.push_back(id);
	cout << id;
}

string str_var_node::evaluate() {  
	return string_map[id]; 
}


string_concat::string_concat(str_node *L, str_node *R) {
	this->left = L;
	this->right = R;
}

void string_concat:: print() {
	left->print();
	cout << " + ";
	right->print();
}

string string_concat::evaluate() {
	string left_num, right_num; 
	
	right_num = right->evaluate(); 
	right_num.erase(
	std::remove(right_num.begin(), right_num.end(), '\"'), 
	right_num.end());
	
	left_num  = left->evaluate();
	left_num.erase(
	std::remove(left_num.begin(), left_num.end(), '\"'), 
	left_num.end());
	
	return "\""+left_num + right_num+"\"";
}

number_node::number_node(float value) {
	num = value;
}

void number_node:: print() {
	cout << num;
}

float number_node::evaluate() { 
	return num; }

boolean_type::boolean_type(bool value) : value(value) {}
void boolean_type:: print() {
	cout << value;
}

float boolean_type::evaluate() { 
	return value; 
}

id_node::id_node(string value) : id(value) {}

void id_node:: print() {
	use_vars.push_back(id);
	cout << id;
}

float id_node::evaluate() { 
	return state[id]; 
}

// plus_node inherits the characteristics of node and adds its own evaluate function
// plus_node's constructor just uses node's constructor
plus_node::plus_node(exp_node *L, exp_node *R) : operator_node(L,R) {
}

void plus_node:: print() {
	cout << "(";
	left->print();
	cout << " + ";
	right->print();
	cout << ")";

}

float plus_node::evaluate() {
	float left_num, right_num;

	left_num  = left->evaluate();
	right_num = right->evaluate();
	
	return left_num + right_num;

}


// minus_node inherits the characteristics of node and adds its own evaluate function
minus_node::minus_node(exp_node *L, exp_node *R) : operator_node(L,R) {
}

void minus_node:: print() {
	cout << "(";
	left->print();
	cout << " - ";
	right->print();
	cout << ")";
}

float minus_node::evaluate() {
	float left_num, right_num;

	left_num  = left->evaluate();
	right_num = right->evaluate();

	return  left_num - right_num;

}


// times_node inherits the characteristics of node and adds its own evaluate function
times_node::times_node(exp_node *L, exp_node *R) : operator_node(L,R) {
}

void times_node:: print() {
	cout << "(";
	left->print();
	cout << " * ";
	right->print();
	cout << ")";
}

float times_node::evaluate() {
	float left_num, right_num;

	left_num = left->evaluate();
	right_num = right->evaluate();

	return left_num * right_num;

}


// divide_node inherits the characteristics of node and adds its own evaluate function

divide_node::divide_node(exp_node *L, exp_node *R) : operator_node(L,R) {
}

void divide_node:: print() {
	cout << "(";
	left->print();
	cout << " / ";
	right->print();
	cout << ")";
}

float divide_node::evaluate() {
	float left_num, right_num;

	left_num = left->evaluate();
	right_num = right->evaluate();

	if(right_num)
	{
		return  left_num / right_num;
	}
	else
	{
		cout << "division by zero -> " << left_num << " / " << 0 << endl;
		//  include stdlib.h for exit
		exit(1);
	}
}

// modulo_node inherits the characteristics of binary node and adds its own evaluate function
modulo_node :: modulo_node(exp_node *L, exp_node *R) : operator_node(L,R) { }
void modulo_node :: print() {
	cout << "(";
	left->print();
	cout << " % ";
	right->print();
	cout << ")";
}

float modulo_node :: evaluate() {
	float left_num, right_num;
	int test;
	left_num = left->evaluate();
	right_num = right->evaluate();

	if(right_num) {
		test = left_num / right_num;  
		return  left_num - test * right_num;
	}
	else {
		cout << "modulo by zero undefined-> " << left_num << " % " << 0 << endl;
		//  include stdlib.h for exit
		exit(1);
	}
}

unary_minus_node::unary_minus_node(exp_node *L) : exp(L) {}

void unary_minus_node:: print() {
	cout << "- ( ";
	exp->print();
	cout << " )";
}

float unary_minus_node::evaluate() {
	float expValue = exp->evaluate();
	return  -expValue;
}

ife_stmt::ife_stmt(test *condition, statement *thenbranch, statement *elsebranch)
{ 
	this -> condition = condition;
	this -> thenbranch = thenbranch;
	this -> elsebranch = elsebranch;
}

void ife_stmt::print(int n) {
	output_tabs(n);  cout << "if ";   condition -> print();   cout  << endl;
	output_tabs(n);  cout << "then { " << endl; 
	thenbranch -> print(n+1);  cout <<  "} " << endl;
	output_tabs(n); cout << "else { " << endl;
	elsebranch -> print(n+1);   cout << "} "; 
}

void ife_stmt::evaluate() {
	if (condition -> evaluate() ) { thenbranch -> evaluate(); }  else { elsebranch -> evaluate(); }
}

TLABEL ife_stmt:: labelling(TLABEL next){  
	TLABEL next1, next2, next3;
	next1 = condition ->labelling(next); 
	next2 = thenbranch ->labelling(next1);
	next3 = elsebranch ->labelling(next2);
	
	//add link from if block to start of then and else block
	vector<int> array;  
	array.push_back(next1);
	array.push_back(next2);
	flow_map[next] = array;
	array.clear();

	//need to change value of next1 and next2
	while(next1 < next2-1){
		next1 += 1;
	}

	while(next2 < next3-1){
		next2 += 1;
	}

	array.push_back(next3); 
	flow_map[next1] = array;
	flow_map[next2] = array;
	array.clear();

	return next3;
}

while_stmt::while_stmt(test *condition, statement *bodystmt)
{ 
	this -> condition = condition;
	this -> bodystmt = bodystmt;
}

void while_stmt::print(int n) {
	output_tabs(n);  cout << "while ";   condition->print();   cout  << " do {" <<endl;
	bodystmt -> print(n+1);  cout <<  "} ";
}

void while_stmt::evaluate() {
	while (condition -> evaluate())  { bodystmt -> evaluate(); } 
}

TLABEL while_stmt:: labelling(TLABEL next){  
	TLABEL next1, next2;
	next1 = condition ->labelling(next); 
	next2 = bodystmt ->labelling(next1);
	
	// previous block-> while condition check block 
	flow_map[next].push_back(next1);
	// end of while -> while condition check block
	flow_map[next2-1].push_back(next);
	flow_map[next].push_back(next2);
	
	//remove connection from last while block -> ouside of loop
	flow_map[next2-1].erase(flow_map[next2-1].begin()+0);
	return next2;
}

input_stmt::input_stmt(string name)
: id(name) {}

void input_stmt::print(int n) {
	output_tabs(n);
	cout << "read " << id ;
	cout << " /* block " << mylabel <<" */";
	
	use_vars.clear();
	use_map[mylabel] = use_vars;   
	def_map[mylabel].push_back(id); 
}

void input_stmt::evaluate() {
	float result;
	cout << "input " << id << ":" << endl;
	cin >> result;
	state[id] = result;
}

TLABEL input_stmt:: labelling(TLABEL next) { 
	flow_map[next].push_back(next+1);
	mylabel = next; return next+1;
}

assignment_stmt :: assignment_stmt(string name, exp_node *expression)
: id(name), exp(expression) {}


void assignment_stmt::print(int n) {
	output_tabs(n);
	cout << id << " = ";

	use_vars.clear();
	exp->print(); 
	def_map[mylabel].push_back(id);
	use_map[mylabel] = use_vars;

	cout << " /* block " << mylabel <<" */";  
}

void assignment_stmt::evaluate() {
	float result = exp->evaluate(); 

	/* if (data_type_check.find(id) == data_type_check.end()) {
		cout << "No data type for key: "<< id <<endl;
	exit(1);  
	} */

	string dataType = data_type_check[id];
	if(dataType == "$bool") {
		result = !!result;  
	} else if(dataType == "$int"){
		result = static_cast<int>(result);
	}
	state[id] = result;
}

TLABEL assignment_stmt:: labelling(TLABEL next) { 
	flow_map[next].push_back(next+1);
	mylabel = next; return next+1;
}

shortqassign_stmt::shortqassign_stmt(short_op s_op,string name,exp_node* exp) :s_op(s_op), id(name), exp(exp) {}
void shortqassign_stmt::print(int n) {

	output_tabs(n);
	cout << id << " ";
	switch(s_op)
	{ case PEQ: cout<< "+="; break;
	case MEQ: cout << "-="; break;
	case TEQ: cout << "*="; break;
	case DEQ: cout << "/="; break;
	case MODEQ: cout<< "%=" ; break;
	} 

	exp->print(); 

	cout << " /* block " << mylabel <<" */";  
}


void shortqassign_stmt::evaluate() {
	float result,final_result,init_value;

	result = exp->evaluate(); 
	def_map[mylabel].push_back(id);
	use_map[mylabel] = use_vars;
	use_vars.clear();
	init_value = state[id];
	switch(s_op)
	{ case PEQ: final_result = init_value + result; break;
	case MEQ: final_result = init_value - result; break;
	case TEQ: final_result = init_value * result; break;
	case DEQ: 
		if(result) {
			final_result = init_value / result;break;
		}else {
			cout << "modulo by zero undefined-> " << init_value << " % " << 0 << endl;
			//  include stdlib.h for exit
			exit(1); break;
		}
	case MODEQ: 
		if(result) {
			final_result = init_value - (init_value / result) * result; break;
		} else {	
			cout << "modulo by zero undefined-> " << init_value << " % " << 0 << endl;
			//  include stdlib.h for exit
			exit(1); break;
		}
	}
	state[id] = final_result;
}

TLABEL shortqassign_stmt:: labelling(TLABEL next) { 
	flow_map[next].push_back(next+1);
	mylabel = next; return next+1;
}


assign_node_type::assign_node_type(string name, exp_node *expression, string datatype) : id(name), exp(expression), datatype(datatype) {}
void assign_node_type::print(int n) {
	output_tabs(n);
	cout << datatype << " " << id << " = ";

	use_vars.clear();
	exp->print();

	def_map[mylabel].push_back(id);
	use_map[mylabel] = use_vars;


	cout << " /* block " << mylabel <<" */"; 
}

void assign_node_type::evaluate() {
	float result = exp->evaluate();
	if(datatype == "$bool") {
		data_type_check[id] = "$bool";
		result = !!result;  
	} else if(datatype == "$int"){
		result = static_cast<int>(result);
		data_type_check[id] = "$int";
	}
	state[id] = result;
}


TLABEL assign_node_type:: labelling(TLABEL next) { 
	flow_map[next].push_back(next+1);
	mylabel = next; return next+1;
}

assign_string::assign_string(string name, str_node *str) : id(name), str(str){}
void assign_string::print(int n) {
	cout << "$string" << " " << id << " = ";
	output_tabs(n);
	cout << id << " = ";

	use_vars.clear();
	str->print(); 
	def_map[mylabel].push_back(id);
	use_map[mylabel] = use_vars;

	cout << " /* block " << mylabel <<" */"; 
}

void assign_string::evaluate() {
	string result = str->evaluate();
	data_type_check[id] = "$string";
	string_map[id] = result;
}


TLABEL assign_string:: labelling(TLABEL next) { 
	flow_map[next].push_back(next+1);
	mylabel = next; return next+1;
}

print_string_node::print_string_node (str_node *str) : str(str) {}

void print_string_node::print(int n) {
	output_tabs(n);
	cout <<  "prints ";
	
	use_vars.clear();
	str->print(); 
	use_map[mylabel] = use_vars;
	def_map[mylabel].push_back("");

	
	cout << " /* block " << mylabel <<" */";    
}

void print_string_node::evaluate() {
	cout << "output: " << str->evaluate() <<endl;
}


TLABEL print_string_node::labelling(TLABEL next) { 
	flow_map[next].push_back(next+1);  
	mylabel = next; return next+1;
}  


print_stmt::print_stmt (exp_node *myexp) : exp(myexp) {}

void print_stmt::print(int n) {
	output_tabs(n);
	cout <<  "print ";
	
	use_vars.clear();
	exp->print(); 
	use_map[mylabel] = use_vars;
	def_map[mylabel].push_back("");

	
	cout << " /* block " << mylabel <<" */";    
}


void print_stmt::evaluate() {
	cout << "output: " << exp->evaluate() << endl << endl;  
}



TLABEL print_stmt::labelling(TLABEL next) { 
	flow_map[next].push_back(next+1);  
	mylabel = next; return next+1;
}  


skip_stmt::skip_stmt ()  {}

void skip_stmt::evaluate() {}
void skip_stmt::print(int n) {
	output_tabs(n); 
	cout << " /* block " << mylabel <<" */"<<endl;   

	def_map[mylabel].push_back("");
	use_map[mylabel].push_back("");
}

TLABEL skip_stmt::labelling(TLABEL next) { 
	flow_map[next].push_back(next+1);
	mylabel = next; 
	return next+1;
}

break_stmt::break_stmt ()  {}

void break_stmt::print(int n) {
	
	output_tabs(n); 
	cout<<"break ";
	cout << " /* block " << mylabel <<" */"<<endl;   

	def_map[mylabel].push_back("");
	use_map[mylabel].push_back("");
}
void break_stmt::evaluate() {
	exit(0);
}

TLABEL break_stmt::labelling(TLABEL next) { 
	flow_map[next].push_back(next+1);
	mylabel = next; 
	return next+1;
}

sequence_stmt::sequence_stmt(statement* mystmt1, statement* mystmt2): 
stmt1(mystmt1), stmt2(mystmt2)
{}

void sequence_stmt::print(int n) {
	stmt1->print(n);  cout << " ;" << endl;
	stmt2->print(n);
}


void sequence_stmt::evaluate() {
	stmt1->evaluate();
	stmt2->evaluate();
}


TLABEL sequence_stmt:: labelling(TLABEL next)
{  TLABEL next1, next2;
	next1 = stmt1 ->labelling(next); 
	next2 = stmt2 ->labelling(next1);
	return next2;
}

bool test::evaluate(){
	return condition -> evaluate();
}

void test::print()
{ 
	use_vars.clear(); 
	condition -> print(); 
	cout << " /* block " << mylabel <<" */";    
	
	use_map[mylabel] = use_vars;
	def_map[mylabel].push_back("");
}

test::test(cond_node *condition) { this->condition = condition; }

TLABEL test::labelling(TLABEL next) {
	mylabel = next; 
	return next+1;
}

array1D_node::array1D_node(string varName, int arraySize, exp_node *arrInitList, string dataType){
	this->variableName = varName;
	this->arraySize = arraySize;
	this->arrInitList = arrInitList;
	this->dataType = dataType;
}
void array1D_node::print(int n) {
	output_tabs(n);
	cout << dataType <<" " << variableName << "[ " << arraySize << " ]" <<" = "<<" { ";

	use_vars.clear();
	arrInitList->print();
	def_map[mylabel].push_back(variableName);
	use_map[mylabel] = use_vars;


	cout << " }";
	cout << " /* block " << mylabel <<" */"; 
}

void array1D_node :: evaluate(){
	arrInitList->evaluate();
	//check init list is same with size given
	if(arraySize == vectorInts.size()){
		vector<float> array;  
		if(dataType == "$int"){
			for (int i = 0; i < vectorInts.size(); i++) {
				array.push_back(static_cast<int>(vectorInts[i]));
			} 
		} else {
			array = vectorInts;
		}
		vectorInts.clear(); 
		array1D[variableName] = array; 
	} else {
		cout << "Array Size and Initializer list length mismatch!! " << endl;
		vectorInts.clear(); 
		exit(1);
	}
}
TLABEL array1D_node:: labelling(TLABEL next) { 
	flow_map[next].push_back(next+1);
	mylabel = next; return next+1;
}

function_arg_list::function_arg_list(exp_node* exp1,exp_node* exp2) {
	this->exp1 = exp1;
	this->exp2 = exp2;
}

function_arg_list::function_arg_list(exp_node* exp1) {
	this->exp1 = exp1;
}

void function_arg_list::print() {
	exp1->print();
	if(exp2 != NULL){
		cout << " , ";
		exp2->print();
	}
}

float function_arg_list::evaluate() {   
	float num1 = exp1->evaluate();
	float num2; 
	if(find(vectorInts.begin(), vectorInts.end(), num1) == vectorInts.end()) {
		vectorInts.push_back(num1);
	} 
	if(exp2 != NULL){
		num2 = exp2->evaluate();
		vectorInts.push_back(num2);
	}
	return num1;
}

change_arr_val::change_arr_val(string arrName, exp_node *arrIndex, exp_node *assignVal){
	this->arrName = arrName;
	this->arrIndex = arrIndex;
	this->assignVal = assignVal;
}

void change_arr_val::print(int n) {
	output_tabs(n);
	cout << arrName << "[ ";

	use_vars.clear();
	arrIndex->print();
	def_map[mylabel].push_back(arrName+"["+use_vars.at(0)+"]");


	cout<< " ]" <<" = ";
	use_vars.clear();
	assignVal->print();
	use_map[mylabel] = use_vars;
	cout << " /* block " << mylabel <<" */"; 
}
void change_arr_val :: evaluate(){
	int index = arrIndex->evaluate();   
	if(index < array1D[arrName].size()){
		array1D[arrName].at(index) = assignVal->evaluate();
	} else {
		cout<< "Array Index Out of bound exception" << endl;
		exit(1);
	}
}

TLABEL change_arr_val:: labelling(TLABEL next) { 
	flow_map[next].push_back(next+1);
	mylabel = next; return next+1;
}

get_arr_element::get_arr_element(string value, exp_node *exp) : arrName(value), exp(exp) {}
void get_arr_element:: print() {
	cout << arrName<< " [ ";
	exp->print();
	cout << " ] "; 
}


float get_arr_element::evaluate() { 
	int index = exp->evaluate();
	float result = 0;
	if(array1D.find( arrName ) != array1D.end()){ 
		if(index < array1D[arrName].size()){   
			result = array1D[arrName].at(index);
		} else {
			cout<< "Array Index Out of bound exception" << endl;
			exit(1);
		}
	} else {
		cout<< "Given array name is not exist in scope"<< endl;
		exit(1);
	}
	return result;
}

function_definition :: function_definition(string returnType, string name, statement* formalArgs, statement* bodyStmt) :
funcReturnType(returnType), funcName(name), funcParams(formalArgs), funcBody(bodyStmt) {}

void function_definition :: print(int n) {
	cout << funcReturnType;
	cout << " ";
	cout << funcName;
	cout << " ";
	cout << "( ";
	if (funcParams != NULL) {
		funcParams->print(n);
	}
	cout << " )";
	cout << " {" <<endl;
	if (funcBody != NULL) {
		funcBody->print(n);
	}
	cout << endl << "}";
}

void function_definition :: evaluate(){
	funcParams->evaluate();
	funcBody->evaluate();
}

TLABEL function_definition:: labelling(TLABEL next) { 
	flow_map[next].push_back(next+1);
	mylabel = next; return next+1;
}


void get_flow(){
	cout <<"{ ";
	for(map<int, vector<int> >::const_iterator it = flow_map.begin();  it != flow_map.end(); ++it) {
		cout <<"{ "<< it->first << "->";
		
		if(it == --flow_map.end() && it != flow_map.end() ){
			cout << "Exit }"; 
		}
		else {
			for (vector<int>::const_iterator b = it->second.begin(); b != it->second.end() ;++b) {
				
				if(b != it->second.begin()){
					cout<< "} " <<"{ "<< it->first << "->" << *b;
				} else {
					cout << *b;
				} 
			}
		}
		cout <<" }";  
	}
	cout << endl<<endl;
}

void kill_gen() { 
  cout<< "\t";
	map<int, vector<string> >::const_iterator it = def_map.begin();
	map<int, vector<string> >::const_iterator use_itr = use_map.begin();

	cout << "     Kill | Gen"<< endl;
	cout<< "\t-------------------"<<endl;
	for( ;  it != def_map.end(), use_itr != use_map.end();++it, ++use_itr) {
		cout<< "\t "<< it->first << " : ";
		vector<string>::const_iterator b = it->second.begin();
		vector<string>::const_iterator iter = use_itr->second.begin();

		for (; b != it->second.end() ; ++b) {    
			cout<<"{";
			if(*b != ""){
				if(b != it->second.begin()){
					cout<< " , "<< *b ;
				} else {
					cout << *b;
				} 
				cout<<"} ";
			}
			else{
				cout << " } ";
			}
			cout<< " | " ;
			// use map
			if (!use_itr->second.empty()) {
				cout<< "{";
				bool print_delim = false;
				for(; iter != use_itr->second.end(); ++iter){
					if(*iter != ""){
						if(print_delim) {
							cout << ", ";
						}
						cout << *iter;
						print_delim = true;
					}  
					
				}
				cout<<"} ";
			} else {
				cout << "{ }";
			}	
		}
		cout << endl;
	}
 cout << endl;
}
void get_LV_entry(){

	cout<<endl;
	map<int, vector<string> >::const_iterator it = def_map.begin();
	map<int, vector<string> >::const_iterator use_itr = use_map.begin();

	for( ;  it != def_map.end() && use_itr != use_map.end() ; ++it, ++use_itr) {

		cout <<"LVentry("<< it->first << ") = ";
		if(def_map.rbegin()->first != it->first){	//check for last element 
			cout << " LVexit("<< it->first <<")";
			for (vector<string>::const_iterator b = it->second.begin(); b != it->second.end() ;++b) {
				if(*b != ""){
					cout<<"\\{";
					if(b != it->second.begin()){
						cout<< " , "<< *b ;
					} else {
						cout << *b;
					}
					cout<<"} ";
				}
			}	
		}
		
		//union with used sets
		if (!use_itr->second.empty()) {
			
			// Check last element
			if(use_map.rbegin()->first != use_itr->first){
				cout<<" U ";
			}
			cout<< " {";
			// To have comma separated values
			bool print_delim = false;       
			for (vector<string>::const_iterator iter = use_itr->second.begin(); iter != use_itr->second.end( ); iter++ ) {
				if(*iter != ""){
					if(print_delim) {
						cout << ", ";
					}
					cout << *iter;
					print_delim = true;
				} 
				
			}
			cout<<"} ";
		}
		cout<<endl;
	}
}

void get_LV_exit(){

	cout << endl;
	for(map<int, vector<int> >::const_iterator it_eq = flow_map.begin();  it_eq != flow_map.end(); ++it_eq) {
		cout <<"LVexit("<< it_eq->first << ") = ";

		if(it_eq == --flow_map.end() && it_eq != flow_map.end() ){
			cout << "{}" <<endl; 
		}
		else {
			for (vector<int>::const_iterator b = it_eq->second.begin(); b != it_eq->second.end() ;++b) {

				if(b == it_eq->second.begin()){
					cout<<"LVentry(" << *b << ")";
				} else {
					cout <<" U LVentry(" << *b << ")";
				} 
			}
			cout << endl;
		}
	}
	cout<<endl;
}

vector<float> vectorInts;
map<string, vector<float> > array1D;
map<string, string> string_map;
map<string, string> data_type_check;
vector<string> use_vars; 
map<int, vector<string> > use_map;
map<int, vector<string> > def_map;
map<int, vector<int> > flow_map;