#include <iostream>
#include <stdlib.h>
#include <string>
#include <map>
#include <list>
#include <vector>
#include <bits/stdc++.h> 

using namespace std;

enum operation {EQ,NTEQL,GE,GRTEQL,LE,LESEQL};
enum short_op {PEQ,MEQ,TEQ,DEQ,MODEQ};

void get_flow();
void kill_gen();
void get_LV_entry();
void get_LV_exit();
void generate_reverse_flow();
void generate_LV_worklist();
void generate_LV_worklist_Que();

class exp_node {
  public:

    // print function for pretty printing an expression
    virtual void print() = 0;

    // evaluation function for a leaf, replaced for interior nodes
    virtual float evaluate() = 0;
};

class operator_node : public exp_node {
public:
    exp_node *left;
    exp_node *right;

  // the constructor for node links the node to its children,
  // and stores the character representation of the operator.
    operator_node(exp_node *L, exp_node *R);
};

class str_node {
public:

	// print function for pretty printing an expression
	virtual void print() = 0;

	// evaluation function for a leaf, replaced for interior nodes
	virtual string evaluate() = 0;
};

class string_node : public str_node {
private:
	string id;
public:
	string_node(string value);
	void print();
	string evaluate();
};

class str_var_node : public str_node {
protected:
	string id;

public:
	str_var_node(string value);
	void print();
	string evaluate();
};

class string_concat : public str_node {
protected:
	str_node *left;
	str_node *right;
public:
	string_concat(str_node *L, str_node *R);
	void print();
	string evaluate();
};

class number_node : public exp_node {
 private:
    float num;

 public:
  number_node(float value);
  void print();
  float evaluate();
};

class boolean_type : public exp_node {
private:
	bool value;
public:
	boolean_type(bool value);
	void print();
	float evaluate();
};

class unary_minus_node : public exp_node {
 protected:
  exp_node *exp;
 public:
  unary_minus_node(exp_node *exp);
  void print();
  float evaluate();
};

class id_node : public exp_node {
protected:
  string id;

public:
  id_node(string value);
  void print();
  float evaluate();
};

// plus_node inherits the characteristics of node and adds its own evaluate function
class plus_node : public operator_node {
  public:

  // plus_node's constructor just uses node's constructor
  plus_node(exp_node *L, exp_node *R);
  void print();
  float evaluate();
};


// minus_node inherits the characteristics of node and adds its own evaluate function
class minus_node : public operator_node {
  public:

  minus_node(exp_node *L, exp_node *R);
  void print();
  float evaluate();
};


// times_node inherits the characteristics of node and adds its own evaluate function
class times_node : public operator_node {
  public:

  times_node(exp_node *L, exp_node *R);
  void print();
  float evaluate();
};


// divide_node inherits the characteristics of node and adds its own evaluate function
class divide_node : public operator_node {
  public:

  divide_node(exp_node *L, exp_node *R);
  void print();
  float evaluate();
};

// modulo_node inherits the characteristics of node and adds its own evaluate function
class modulo_node : public operator_node {
public:
	modulo_node(exp_node *L, exp_node *R);
	void print();
	float evaluate();
};

class cond_node {
  public:

    // print function for pretty printing an expression
    virtual void print() = 0;

    // evaluation function for a leaf, replaced for interior nodes
    virtual bool evaluate() = 0;
};


class or_cond_node : public cond_node {
private:
  cond_node *left, *right;

 public:
    or_cond_node(cond_node *L, cond_node *R);
    void print();
    bool evaluate(); 
};

class and_cond_node : public cond_node {
private:
  cond_node *left, *right;

public:
  and_cond_node(cond_node *L, cond_node *R);
    void print();
    bool evaluate(); 
};

class neg_cond_node : public cond_node {
 private:
    cond_node *child;

 public:
    neg_cond_node(cond_node *child);
    void print();
    bool evaluate(); 
};


class prim_cond_node : public cond_node {
private:
  operation op; 
  exp_node *left, *right;

public:
  prim_cond_node(operation op, exp_node *L, exp_node *R);
    void print();
    bool evaluate(); 
};


//typedef int A[]; // A is int[]
//A a = {1, 2}, b = {3,4,5}; // type of a is int[2], type of b is int[3]

typedef int TLABEL;

class basic_block { 
 protected: TLABEL mylabel;
};


class test: public basic_block { 
 private: 
  cond_node *condition;
 public: 
  test(cond_node *condition); 
  void print();
  bool evaluate(); 
  /*TLABEL labelling(TLABEL next) {
  mylabel = next; 
  return next+1;}*/
  TLABEL labelling(TLABEL);  
}; 





class statement {
 public:
  virtual void print(int) {}
  virtual void evaluate() = 0;
  virtual TLABEL labelling(TLABEL next) =0;
};

class ife_stmt : public statement {
 protected:
  test *condition;
  statement *thenbranch, *elsebranch;
 public:
  ife_stmt(test  *condition, statement *thenbranch, statement *elsebranch);
  void print(int);
  void evaluate();
  TLABEL labelling(TLABEL);
};

class while_stmt : public statement {
 protected:
  test *condition;
  statement *bodystmt;
 public:
  while_stmt(test  *condition, statement *bodystmt);
  void print(int);
  void evaluate();
  TLABEL labelling(TLABEL);
};

class input_stmt : public statement,basic_block {
 protected:
  string id;
 public:
  input_stmt(string name);
  void print(int);
  void evaluate();
  TLABEL labelling(TLABEL);
};



class assignment_stmt : public statement, public basic_block {
 protected:
  string id;
  exp_node *exp;
 public:
  assignment_stmt(string name, exp_node *expression);
  void print(int);
  void evaluate();
  TLABEL labelling(TLABEL);
};

class shortqassign_stmt: public statement, public basic_block  {
protected:
  short_op s_op;
  string id;
  exp_node *exp;
public:
	shortqassign_stmt(short_op s_op ,string name, exp_node *expression);
	void print(int);
	void evaluate();
  TLABEL labelling(TLABEL);
};

class assign_node_type : public statement, public basic_block {
protected:
	string id;
	exp_node *exp;
	string datatype;
public:
	assign_node_type(string name, exp_node *expression,string datatype);
	void print(int);
	void evaluate();
	TLABEL labelling(TLABEL);
};

class assign_string : public statement, public basic_block {
protected:
	string id;
	str_node *str;
public:
	assign_string(string name, str_node *str);
	void print(int);
	void evaluate();
  TLABEL labelling(TLABEL);
};

class print_string_node: public statement, public basic_block {
protected:
	str_node *str;
public:
	print_string_node(str_node *str);
	void print(int);
	void evaluate();
  TLABEL labelling(TLABEL);
};

class print_stmt: public statement, public basic_block {
 protected:
  exp_node *exp;
 public:
  print_stmt(exp_node *myexp);
  void print(int);
  void evaluate();
   TLABEL labelling(TLABEL);    
};

class skip_stmt: public statement, public basic_block {
 public:
  skip_stmt();
  void print(int);
  void evaluate();
  TLABEL labelling(TLABEL);
};

class break_stmt: public statement, public basic_block {
public:
	break_stmt();
	void print(int);
	void evaluate();
 TLABEL labelling(TLABEL);
};

class sequence_stmt: public statement {
 protected:
  statement *stmt1, *stmt2;
 public:
  sequence_stmt(statement *mystmt1, statement *mystmt2);
  void print(int);
  void evaluate();
  TLABEL labelling(TLABEL);
};

class array1D_node : public statement, public basic_block{
protected:  
	string variableName;
	int arraySize;
	exp_node *arrInitList;
	string dataType;

public:
	array1D_node(string varName, int arraySize, exp_node *arrInitList, string dataType);
	void print(int);
	void evaluate();
	TLABEL labelling(TLABEL);
};

class function_arg_list: public exp_node {
protected:
	exp_node* exp1;
	exp_node* exp2;

public:
	function_arg_list(exp_node* exp1, exp_node* exp2);
	function_arg_list(exp_node* exp1);
	void print();
	float evaluate();
};


class get_arr_element : public exp_node{
protected:
	string arrName;
	exp_node *exp;

public:
	get_arr_element(string value, exp_node *exp);
	void print();
	float evaluate();
};

class change_arr_val : public statement, public basic_block {
protected:
	string arrName;
	exp_node *arrIndex;
	exp_node *assignVal;
public: 
	change_arr_val(string arrName, exp_node *arrIndex, exp_node *assignVal);
	void print(int);
	void evaluate(); 
	TLABEL labelling(TLABEL);	
};

class function_definition: public statement, public basic_block  {
protected:
	string funcReturnType;
	string funcName;
	statement* funcParams;
	statement* funcBody;

public:
	function_definition(string returnType, string name, statement* formalArgs, statement* bodyStmt);
	void print(int);
	void evaluate();
  TLABEL labelling(TLABEL);	
};

extern queue <int> worklist_que;
extern stack <int> worklist_stack;
extern vector<float> vectorInts;
extern map<string, vector<float> > array1D;
extern map<string, string> string_map;
extern map<string, string> data_type_check;
extern vector<string> use_vars; 
extern map<int, vector<string> > use_map;
extern map<int, vector<string> > def_map;
extern map<int, vector<int> > flow_map;
extern map<int, vector<int> > reverse_flow_map;